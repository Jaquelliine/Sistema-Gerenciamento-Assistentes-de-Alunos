/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projeto.integrador.model;

import javax.swing.JOptionPane;

/**
 *
 * @author Veson
 */
public class Login {
    String Acesso = "";
    public void getTipoAcesso(String boxTipoAcesso){
        Acesso = boxTipoAcesso;
    }
    private String TipoAcesso=Acesso;
    private String Siap;
    private String Senha;
    private String Email;

    /**
     * @return the TipoAcesso
     */
    public String getTipoAcesso() {
        return TipoAcesso;
    }

    /**
     * @param TipoAcesso the TipoAcesso to set
     */
    public void setTipoAcesso(String TipoAcesso) {
        this.TipoAcesso = TipoAcesso;
    }

    /**
     * @return the Siap
     */
    public String getSiap() {
        return Siap;
    }

    /**
     * @param Siap the Siap to set
     */
    public void setSiap(String Siap) {
        this.Siap = Siap;
    }

    /**
     * @return the Senha
     */
    public String getSenha() {
        return Senha;
    }

    /**
     * @param Senha the Senha to set
     */
    public void setSenha(String Senha) {
        this.Senha = Senha;
    }

    /**
     * @return the Email
     */
    public String getEmail() {
        return Email;
    }

    /**
     * @param Email the Email to set
     */
    public void setEmail(String Email) {
        this.Email = Email;
    }

}
