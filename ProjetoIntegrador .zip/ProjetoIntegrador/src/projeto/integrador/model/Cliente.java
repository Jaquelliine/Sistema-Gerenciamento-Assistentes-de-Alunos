/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projeto.integrador.model;

/**
 *
 * @author L
 */
public class Cliente {

    private int pk_cliente;
    private String nomeCliente;
    private String DataNascimento;
    private String CPF;
    private String TelefoneCliente;
 
    

    public Cliente(String nomeCliente, String DataNascimento, String CPF,String TelefoneCliente) {
        this.nomeCliente = nomeCliente;
        this.DataNascimento = DataNascimento;
        this.CPF = CPF;
        this.TelefoneCliente = TelefoneCliente;
       
       
    }

    public Cliente(int pk_cliente, String nomeCliente, String DataNascimento, String CPF,String TelefoneCliente) {
        this.pk_cliente = pk_cliente;
        this.nomeCliente = nomeCliente;
        this.DataNascimento = DataNascimento;
        this.CPF = CPF;
        this.TelefoneCliente = TelefoneCliente;
        ;
    }

    Cliente(String nome, String cpf) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public Cliente(int pk_cliente, String string, String string0, Endereco e) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public Cliente(int aInt, String string, String string0, String string1, String string2, Endereco e) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public Cliente(String text, String text0, double parseDouble) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public Cliente(String text, String text0, double parseDouble, String text1) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public int getPk_cliente() {
        return pk_cliente;
    }

    public void setPk_cliente(int pk_cliente) {
        this.pk_cliente = pk_cliente;
    }
    
    public String getNome() {
        return nomeCliente;
    }

    public void setNome(String nomeCliente) {
        if (nomeCliente.length()<=80){
            this.nomeCliente = nomeCliente;
        } else {
            throw new RuntimeException("Tamanho máximo do nome é de 80 caracteres");
        }
    }

    public String getCPF() {
        return CPF;
    }

    public void setCPF(String CPF) {
        this.CPF = CPF;
    }

    
    public String getDataNascimento() {
        return DataNascimento;
    }

    public void setDataNascimento(String DataNascimento) {
        this.DataNascimento = DataNascimento;
    }
    
    
    public String getTelefoneCliente() {
        return TelefoneCliente;
    }

    public void setTelefoneCliente(String TelefoneCliente) {
        this.TelefoneCliente = TelefoneCliente;
    }

    

    @Override
    public String toString() {
        return "Cliente{" + "Nome=" + nomeCliente + ", Data de Nascimento=" + DataNascimento  + ", CPF=" + CPF + ", Telefone=" + TelefoneCliente + '}';
    }

    public String getnomeCliente() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

}

