/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projeto.integrador.model;

import javax.swing.JOptionPane;

/**
 *
 * @author Veson
 */
public class CadastroPessoas {
 
   private String CadastroNome;
    private String CadastroEmail;
    private int CadastroSIAPE;
    private String CadastroSenha;
    private String CadastroConfirmaSenha;


    public CadastroPessoas() {
    }

    public CadastroPessoas(String CadastroNome, String CadastroEmail, int CadastroSIAPE, String CadastroSenha , String CadastroConfirmaSenha) {
        this.CadastroNome = CadastroNome;
        this.CadastroEmail = CadastroEmail;
        this.CadastroSIAPE = CadastroSIAPE;
        this.CadastroSenha = CadastroSenha;
        this.CadastroConfirmaSenha = CadastroConfirmaSenha;
    }

    public String getCadastroNome() {
        return CadastroNome;
    }

    public void setCadastroNome(String CadastroNome) {
        this.CadastroNome = CadastroNome;
    }

    public String getCadastroEmail() {
        return CadastroEmail;
    }

    public void setCadastroEmail(String CadastroEmail) {
        this.CadastroEmail = CadastroEmail;
    }

       public int getCadastroSIAPE() {
        return CadastroSIAPE;
    }

    public void setCadastroSIAPE(int CadastroSIAPE) {
        this.CadastroSIAPE = CadastroSIAPE;
    }
       public String getCadastroSenha() {
        return CadastroSenha;
    }

    public void setCadastroSenha(String CadastroSenha) {
        this.CadastroSenha = CadastroSenha;
    }
       public String getCadastroConfirmaSenha() {
        return CadastroConfirmaSenha;
    }

    public void setCadastroConfirmaSenha(String CadastroConfirmaSenha) {
        this.CadastroConfirmaSenha = CadastroConfirmaSenha;
    }
}
    