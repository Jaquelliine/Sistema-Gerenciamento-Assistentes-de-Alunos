/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projeto.integrador.dao;
// faz as importações
import projeto.integrador.model.Cliente;
import projeto.integrador.model.Endereco;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * @author Jaqueline Lopes
 */
public class ClienteDAO {
//Cria e insere os  dados no banco
       public static int create(Cliente c) {
        try {
            Statement stm = BancoDados.createConnection().createStatement();

            String sql =
                    "insert into clientes (nomeCliente,DataNascimento,CPF,TelefoneCliente) values ('" +
                            c.getnomeCliente() + "','" +
                            c.getDataNascimento() +
                            c.getCPF() +
                            c.getTelefoneCliente() + "')";

            stm.execute(sql, Statement.RETURN_GENERATED_KEYS);
            ResultSet rs = stm.getGeneratedKeys();
            rs.next();
            int key = rs.getInt(1);
            c.setPk_cliente(key);

            return key;
        } catch (SQLException ex) {
            Logger.getLogger(ClienteDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return 0;
    }

    public static Cliente retreave(int pk_cliente) {
        try {
            Statement stm =
                    BancoDados.createConnection().
                            createStatement();

            String sql = "select * from clientes where pk_cliente =" + pk_cliente;

            ResultSet rs = stm.executeQuery(sql);
            rs.next();

            Endereco e = EnderecoDAO.retreaveByCliente(pk_cliente);
            return new Cliente(pk_cliente,
                    rs.getString("nome"),
                    rs.getString("DataNascimento"),
                    rs.getString("CPF"),
                    rs.getString("TelefoneCliente"),
                    e);
        } catch (SQLException ex) {
            Logger.getLogger(ClienteDAO.class.getName()).log(Level.SEVERE, null, ex);
        }


        return null;
    }

    public static ArrayList<Cliente> retreaveAll() {
        try {
            Statement stm =
                    BancoDados.createConnection().
                            createStatement();
// seleciona o banco
            String sql = "SELECT * FROM clientes";

            ResultSet rs = stm.executeQuery(sql);
            ArrayList<Cliente> cs = new ArrayList<>();
            while (rs.next()) {
                Endereco e = EnderecoDAO.retreaveByCliente(rs.getInt("pk_cliente"));
                cs.add(new Cliente(
                        rs.getInt("pk_cliente"),
                        rs.getString("nome"),
                        rs.getString("DataNascimento"),
                        rs.getString("CPF"),
                        rs.getString("TelefoneCliente"),
                        e));
            }

            return cs;
        } catch (SQLException ex) {
            Logger.getLogger(ClienteDAO.class.getName()).log(Level.SEVERE, null, ex);
        }


        return null;
    }

    public static boolean update(Cliente c) {
        try {
            Statement stm = BancoDados.createConnection().createStatement();

            String sql =
                    "update clientes set " +
                            "nome='" + c.getnomeCliente() + "'," +
                            " DataNascimento='" + c.getDataNascimento() + "' " +
                            " cpf='" + c.getCPF() + "' " +
                            " TelefoneCliente='" + c.getTelefoneCliente() + "' " +    
                    
                            "where pk_cliente = " + c.getPk_cliente();
            stm.execute(sql);

            return true;
        } catch (SQLException ex) {
            Logger.getLogger(ClienteDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }

    public static boolean delete(Cliente c) {
        try {
            Statement stm = BancoDados.createConnection().createStatement();

            String sql =
                    "delete from clientes "+
                            " where pk_cliente = " + c.getPk_cliente();
            stm.execute(sql);
            ResultSet rs = stm.getGeneratedKeys();
            rs.next();
            
            return true;
        } catch (SQLException ex) {
            Logger.getLogger(ClienteDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }

}
