/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projeto.integrador.dao;

/**
 *
 * @author Jaqueline Lopes
 */
// faz a configuração do banco de dados e sua conexão
public class BDConfig {

    public static final String URL = "jdbc:mysql://localhost/projetointegrador";
    public static final String USR = "root";
    public static final String PWD = "";
    public static final String DRIVER = "com.mysql.jdbc.Driver";

}
