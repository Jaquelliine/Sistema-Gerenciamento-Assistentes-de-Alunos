package Control;

import java.sql.Connection;//se quiser mudar o banco de dados muda só o driver e o url.
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Conexao {
    
     private static final String DRIVER = "com.mysql.jdbc.Driver";//final cria uma constante. Carregar o drive;
    private static final String URL = "jdbc:mysql://localhost:3306/SistemaReserva";
    private static final String USER = "root";
    private static final String PASS = "";
    
    public static Connection getConnection(){//Criar método publico para obter as conexões. Adcionar importação para java.sql.connection.
        try {
            
        Class.forName(DRIVER);//Carrega uma classe do driver.
        
        return DriverManager.getConnection(URL, USER, PASS);
        
        } catch (ClassNotFoundException | SQLException ex) {
            throw new RuntimeException(" Erro na conexão: ",ex);
        }
    }
    public static void closeConnection(Connection con){
        try {
        if(con != null){
                con.close();
        }
        } catch (SQLException ex) {
                Logger.getLogger(Conexao.class.getName()).log(Level.SEVERE, null, ex);
            
        }
    }
    public static void closeConnection(Connection con,PreparedStatement stmt){
        closeConnection(con);
        try {
           if(stmt != null){
               stmt.close();
           }
        } catch (SQLException ex) {
                Logger.getLogger(Conexao.class.getName()).log(Level.SEVERE, null, ex);
            
        }
    }
    public static void closeConnection(Connection con,PreparedStatement stmt, ResultSet rs){
        closeConnection(con, stmt);
        try {
           if(rs != null){
               rs.close();
           }
        } catch (SQLException ex) {
                Logger.getLogger(Conexao.class.getName()).log(Level.SEVERE, null, ex);
            
        }
    }
}
