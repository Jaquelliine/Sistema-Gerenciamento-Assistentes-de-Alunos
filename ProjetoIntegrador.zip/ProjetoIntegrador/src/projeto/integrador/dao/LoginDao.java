/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projeto.integrador.dao;

import Control.Conexao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.UIManager;
import model.bean.Login;
import java.sql.ResultSet;

/**
 *
 * @author Veson
 */
public class LoginDao {
    private ResultSet rs;
     public void create(Login L){
        
        Connection con = Conexao.getConnection();
        
        PreparedStatement stmt = null;
        
        try {
            stmt = con.prepareStatement("INSERT INTO Login(TipoAcesso,Siap,Senha,Email)VALUES(?,?,?,?)");
            stmt.setString(1,L.getTipoAcesso());
            stmt.setString(2,L.getSiap());
            stmt.setString(3,L.getSenha());
            stmt.setString(4,L.getEmail());
            
            stmt.executeUpdate();
            
            
            
        } catch (SQLException ex) {
            Logger.getLogger(LoginDao.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            Conexao.closeConnection(con, stmt);
        }
    }
}
