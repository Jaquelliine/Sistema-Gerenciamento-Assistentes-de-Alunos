package projeto.integrador.tads;

import projeto.integrador.dao.VendaDAO;
import projeto.integradorl.model.Venda;
import java.text.ParseException;
import java.util.ArrayList;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * @author Jaqueline Lopes
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws ParseException {

        Venda v = new Venda();

 v.setNomeCliente("Marcio Lucas");

        ArrayList<Venda> vendas = VendaDAO.retreave();
        for (Venda vds : vendas) {

            System.out.println("-----------------------------------------------");
            // passa o valor tota da nota gerada
            System.out.println("Valor total da nota: R$ " + vds.getValorTotal());
            //mostra a data do faturamento
            System.out.println("Data do faturamento: " + vds.getDataFaturamento());
            //valor das parcelas
            System.out.println("3 x de R$ " + vds.divideNf(vds.getValorTotal()));
            //valor da comissao do representante em cada parcela
            System.out.println("Comissão do representante por parcela: " +
                    vds.retornaComissaoRepresentantePorParcela(vds.getValorTotal()));
            //valor da comissao total por cliente
            System.out.println("Comissão do representante total: " +
                    vds.retornaComissaoRepresentanteTotal(vds.getValorTotal()));
            String[] datas = vds.retornaDatasVencimentoParcelaNf(vds.getDataFaturamento());
            //datas de vencimento das parcelas
            System.out.println(" > Vencimentos");
            for (int i = 0; i < datas.length; i++) {
                //faz calculo do vencimento
                System.out.println("   + Vencimentos nas datas " + vds.retornaDatasVencimentoParcelaNf(vds.getDataFaturamento())[i] + " ");
            }
            //retorna os pagamentos em suas respectivas datas
            System.out.println(" > Pagamentos");
            for (int i = 0; i < datas.length; i++) {
                System.out.println("   + Pagamentos nas datas " + vds.retornaDiaPagamento(vds.retornaDatasVencimentoParcelaNf(vds.getDataFaturamento()))[i] + " ");
            }
            System.out.println("-----------------------------------------------");
        }
        ArrayList<Venda> totais = VendaDAO.somaValores("data_faturamento >= '2016-11-27' && data_faturamento <= '2016-11-29'");
        for (Venda total: totais) {
           // retorna o total liquido 
            System.out.println("TOTAL LIQUIDO DO PERÍODO: "+total.getValorTotal());
            //retorna o total da comissão com base no total
            System.out.println("TOTAL COMISSÃO DO PERÍODO: "+total.retornaComissaoRepresentanteTotal(total.getValorTotal()));
        }
    }

}

